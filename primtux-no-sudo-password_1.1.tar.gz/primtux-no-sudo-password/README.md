# primtux-no-sudo-password
Retrait de la demande du mot de passe sudo sur administrateur

## Modification systeme

Installe juste fichier de configuration dans */etc/sudoer.d/* et le man.
